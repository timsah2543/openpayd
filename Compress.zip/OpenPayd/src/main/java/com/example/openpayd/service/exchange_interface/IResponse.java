package com.example.openpayd.service.exchange_interface;

import java.io.Serializable;


public interface IResponse extends Serializable
{
}
